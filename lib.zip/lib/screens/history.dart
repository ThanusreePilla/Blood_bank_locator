import 'package:flutter/material.dart';
import 'results.dart';

class History extends StatelessWidget {
  const History({super.key});

  static const searches = [
    {'group': 'O+', 'location': 'Central City'},
    {'group': 'A-', 'location': 'North Avenue'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search History'),
      ),
      body: searches.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No searches yet. Your recent searches will appear here.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView(
              padding: const EdgeInsets.all(20),
              children: [
                const Text(
                  'Temporary prototype history',
                  style: TextStyle(fontSize: 16),
                ),
                const SizedBox(height: 16),
                ...searches.map((search) {
                  final group = search['group']!;
                  final location = search['location']!;
                  return Card(
                    margin: const EdgeInsets.only(bottom: 12),
                    child: ListTile(
                      leading: const Icon(Icons.history),
                      title: Text('$group blood'),
                      subtitle: Text(location),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => Results(
                              bloodGroup: group,
                              location: location,
                            ),
                          ),
                        );
                      },
                    ),
                  );
                }),
              ],
            ),
    );
  }
}