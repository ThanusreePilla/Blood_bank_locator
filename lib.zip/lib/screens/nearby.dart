import 'package:flutter/material.dart';
import 'results.dart';

class Nearby extends StatelessWidget {
  const Nearby({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Nearby Blood Banks'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.info_outline),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'These are sample nearby results for the prototype. GPS is not connected yet.',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          ...Results.bloodBanks.map((bank) {
            final groups = bank['groups'] as List<String>;
            return Card(
              margin: const EdgeInsets.only(bottom: 14),
              child: ListTile(
                contentPadding: const EdgeInsets.all(16),
                leading: CircleAvatar(
                  backgroundColor:
                      Theme.of(context).colorScheme.primaryContainer,
                  child: const Icon(Icons.local_hospital_outlined),
                ),
                title: Text(
                  bank['name'] as String,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Text(
                    '${bank['location']}\nAvailable groups: ${groups.join(', ')}',
                  ),
                ),
                isThreeLine: true,
                trailing: IconButton(
                  tooltip: 'Show contact',
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Contact: ${bank['contact']}')),
                    );
                  },
                  icon: const Icon(Icons.phone_outlined),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}