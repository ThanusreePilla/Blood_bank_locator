import 'package:flutter/material.dart';

class Stock extends StatefulWidget {
  const Stock({super.key});

  static final stockValues = <String, int>{
    'A+': 24,
    'A-': 8,
    'B+': 16,
    'B-': 0,
    'AB+': 6,
    'AB-': 3,
    'O+': 31,
    'O-': 0,
  };

  @override
  State<Stock> createState() => _StockState();
}

class _StockState extends State<Stock> {
  late final Map<String, int> stock;

  @override
  void initState() {
    super.initState();
    stock = Stock.stockValues;
  }

  String statusFor(int units) {
    if (units == 0) return 'Unavailable';
    if (units < 10) return 'Low stock';
    return 'Available';
  }

  Color statusColor(BuildContext context, int units) {
    if (units == 0) return Theme.of(context).colorScheme.error;
    if (units < 10) return Colors.orange.shade800;
    return Colors.green.shade700;
  }

  Future<void> editUnits(String group) async {
    final controller = TextEditingController(text: '${stock[group]}');
    final updatedUnits = await showDialog<int>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Update $group stock'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Available units',
              prefixIcon: Icon(Icons.inventory_2_outlined),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                final units = int.tryParse(controller.text.trim());
                if (units != null && units >= 0) {
                  Navigator.pop(context, units);
                }
              },
              child: const Text('Save'),
            ),
          ],
        );
      },
    );
    controller.dispose();

    if (updatedUnits != null) {
      setState(() {
        stock[group] = updatedUnits;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manage Blood Stock'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Current inventory',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          const Text('Review available units and update temporary stock values.'),
          const SizedBox(height: 24),
          ...stock.entries.map((entry) {
            final color = statusColor(context, entry.value);
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              child: ListTile(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 6,
                ),
                leading: CircleAvatar(
                  backgroundColor: color.withValues(alpha: 0.12),
                  child: Text(
                    entry.key,
                    style: TextStyle(
                      color: color,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                title: Text('${entry.value} units'),
                subtitle: Text(
                  statusFor(entry.value),
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                trailing: IconButton(
                  tooltip: 'Edit ${entry.key} stock',
                  onPressed: () => editUnits(entry.key),
                  icon: const Icon(Icons.edit_outlined),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}