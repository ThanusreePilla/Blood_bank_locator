import 'package:flutter/material.dart';
import 'welcome.dart';

  class BankProfile extends StatefulWidget {
  const BankProfile({super.key});

  @override
  State<BankProfile> createState() => _BankProfileState();
}

class _BankProfileState extends State<BankProfile> {
  String bankName = 'City Care Blood Bank';
  String address = 'Central City, Main Avenue';
  String phone = '+1 555 010 1001';
  String email = 'contact@citycare.example';
  String bankType = 'Community blood bank';

  void logout() {
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const Welcome()),
      (route) => false,
    );
  }

  Future<void> editProfile() async {
    final nameController = TextEditingController(text: bankName);
    final addressController = TextEditingController(text: address);
    final phoneController = TextEditingController(text: phone);
    final emailController = TextEditingController(text: email);
    final typeController = TextEditingController(text: bankType);

    final updatedProfile = await showDialog<List<String>>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Edit Bank Profile'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(labelText: 'Bank name'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: addressController,
                  decoration: const InputDecoration(labelText: 'Address'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: phoneController,
                  decoration: const InputDecoration(labelText: 'Phone'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: emailController,
                  decoration: const InputDecoration(labelText: 'Email'),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: typeController,
                  decoration: const InputDecoration(labelText: 'Blood-bank type'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.pop(context, [
                nameController.text.trim(),
                addressController.text.trim(),
                phoneController.text.trim(),
                emailController.text.trim(),
                typeController.text.trim(),
              ]),
              child: const Text('Save'),
            ),
          ],
        );
      },
    );

    nameController.dispose();
    addressController.dispose();
    phoneController.dispose();
    emailController.dispose();
    typeController.dispose();

    if (updatedProfile != null &&
        updatedProfile.every((value) => value.isNotEmpty)) {
      setState(() {
        bankName = updatedProfile[0];
        address = updatedProfile[1];
        phone = updatedProfile[2];
        email = updatedProfile[3];
        bankType = updatedProfile[4];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Blood Bank Profile'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 30,
                    backgroundColor: Theme.of(context)
                        .colorScheme
                        .primaryContainer,
                    child: const Icon(Icons.local_hospital_outlined, size: 30),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      bankName,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Bank information',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 16),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.location_on_outlined),
                    title: Text('Address'),
                    subtitle: Text(address),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.phone_outlined),
                    title: Text('Contact number'),
                    subtitle: Text(phone),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.email_outlined),
                    title: Text('Email'),
                    subtitle: Text(email),
                  ),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.info_outline),
                    title: Text('Blood-bank type'),
                    subtitle: Text(bankType),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 24),
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: editProfile,
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Edit Profile'),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: logout,
            icon: const Icon(Icons.logout),
            label: const Text('Logout'),
          ),
        ],
      ),
    );
  }
}