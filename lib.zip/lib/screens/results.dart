import 'package:flutter/material.dart';
import 'details.dart';

class Results extends StatelessWidget {
  const Results({
    super.key,
    required this.bloodGroup,
    required this.location,
  });

  final String bloodGroup;
  final String location;

  static const bloodBanks = [
    {
      'name': 'City Care Blood Bank',
      'location': 'Central City',
      'contact': '+1 555 010 1001',
      'groups': ['A+', 'A-', 'B+', 'O+'],
    },
    {
      'name': 'LifeLine Blood Center',
      'location': 'North Avenue',
      'contact': '+1 555 010 1002',
      'groups': ['B-', 'AB+', 'AB-', 'O-'],
    },
    {
      'name': 'Hope Community Blood Bank',
      'location': 'West District',
      'contact': '+1 555 010 1003',
      'groups': ['A+', 'B+', 'AB+', 'O+'],
    },
  ];

  @override
  Widget build(BuildContext context) {
    final matchingBanks = bloodBanks
        .where((bank) => (bank['groups'] as List<String>).contains(bloodGroup))
        .toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Blood Bank Results'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'Blood banks near $location',
            style: const TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              const Icon(Icons.water_drop_outlined, size: 20),
              const SizedBox(width: 8),
              Text(
                'Requested blood group: $bloodGroup',
                style: const TextStyle(fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 24),
          if (matchingBanks.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  children: [
                    Icon(Icons.search_off, size: 42),
                    SizedBox(height: 12),
                    Text(
                      'No sample blood banks have this blood group available.',
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            )
          else
            ...bloodBanks.map((bank) {
              final groups = bank['groups'] as List<String>;
              final isAvailable = groups.contains(bloodGroup);

              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: InkWell(
                  borderRadius: BorderRadius.circular(12),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Details(
                          bank: bank,
                          bloodGroup: bloodGroup,
                        ),
                      ),
                    );
                  },
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                      Text(
                        bank['name'] as String,
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          const Icon(Icons.location_on_outlined, size: 18),
                          const SizedBox(width: 6),
                          Text(bank['location'] as String),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Icon(
                            isAvailable ? Icons.check_circle : Icons.cancel,
                            color: isAvailable ? Colors.green : Colors.red,
                            size: 18,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            isAvailable
                                ? '$bloodGroup available'
                                : '$bloodGroup not available',
                            style: TextStyle(
                              color: isAvailable ? Colors.green : Colors.red,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text('Available groups: ${groups.join(', ')}'),
                      const SizedBox(height: 8),
                      Text('Contact: ${bank['contact']}'),
                      const SizedBox(height: 14),
                        OutlinedButton.icon(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Details(
                                  bank: bank,
                                  bloodGroup: bloodGroup,
                                ),
                              ),
                            );
                          },
                          icon: const Icon(Icons.info_outline),
                          label: const Text('View details'),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
        ],
      ),
    );
  }
}