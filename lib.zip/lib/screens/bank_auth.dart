import 'package:flutter/material.dart';
import 'bank_home.dart';

class BankAuth extends StatefulWidget {
  const BankAuth({super.key});

  @override
  State<BankAuth> createState() => _BankAuthState();
}

class _BankAuthState extends State<BankAuth> {
  bool login = false;

  final bankNameController = TextEditingController();
  final contactController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  @override
  void dispose() {
    bankNameController.dispose();
    contactController.dispose();
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void authenticate() {
    final requiredValues = [
      if (!login) bankNameController.text,
      if (!login) contactController.text,
      emailController.text,
      passwordController.text,
    ];

    if (requiredValues.any((value) => value.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter all required details.')),
      );
      return;
    }

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const BankHome()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          login ? 'Blood Bank Login' : 'Register Blood Bank',
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 25),

            Text(
              login ? 'Welcome back' : 'Register your blood bank',
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            Text(
              login
                  ? 'Sign in to manage your blood bank.'
                  : 'Create an account to manage your bank information and blood availability.',
              style: const TextStyle(fontSize: 16),
            ),

            const SizedBox(height: 30),

            if (!login) ...[
              TextField(
                controller: bankNameController,
                decoration: InputDecoration(
                  labelText: 'Blood Bank Name',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 16),

              TextField(
                controller: contactController,
                decoration: InputDecoration(
                  labelText: 'Contact Number',
                  border: OutlineInputBorder(),
                ),
              ),

              const SizedBox(height: 16),
            ],

            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16),

            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 24),

            SizedBox(
              width: double.infinity,
              height: 52,
              child: ElevatedButton(
                onPressed: authenticate,
                child: Text(
                  login ? 'Sign In' : 'Register Blood Bank',
                ),
              ),
            ),

            const SizedBox(height: 18),

            Center(
              child: TextButton(
                onPressed: () {
                  setState(() {
                    login = !login;
                  });
                },
                child: Text(
                  login
                      ? 'New bank? Register here'
                      : 'Already registered? Sign in',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}