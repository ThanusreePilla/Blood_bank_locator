import 'package:flutter/material.dart';
import 'bank_profile.dart';
import 'stock.dart';
import 'welcome.dart';

class BankHome extends StatefulWidget {
  const BankHome({super.key});

  @override
  State<BankHome> createState() => _BankHomeState();
}

class _BankHomeState extends State<BankHome> {
  String statusFor(int units) {
    if (units == 0) return 'Out of Stock';
    if (units < 10) return 'Low';
    return 'Available';
  }

  Color statusColor(int units) {
    if (units == 0) return Colors.red;
    if (units < 10) return Colors.orange.shade800;
    return Colors.green.shade700;
  }

  @override
  Widget build(BuildContext context) {
    final totalUnits = Stock.stockValues.values.reduce((a, b) => a + b);
    final availableGroups =
      Stock.stockValues.values.where((units) => units > 0).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Blood Bank Dashboard'),
        actions: [
          IconButton(
            tooltip: 'View profile',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const BankProfile(),
                ),
              );
            },
            icon: const Icon(Icons.account_circle_outlined),
          ),
          IconButton(
            tooltip: 'Log out',
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const Welcome()),
                (route) => false,
              );
            },
            icon: const Icon(Icons.logout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Text(
            'City Care Blood Bank',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 6),
          const Text('Welcome back. Keep your blood stock up to date.'),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  Icon(
                    Icons.check_circle,
                    color: Colors.green.shade700,
                    size: 28,
                  ),
                  const SizedBox(width: 12),
                  const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Current status',
                        style: TextStyle(fontWeight: FontWeight.w600),
                      ),
                      SizedBox(height: 4),
                      Text('Accepting blood requests'),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _SummaryCard(
                  icon: Icons.inventory_2_outlined,
                  label: 'Total units',
                  value: '$totalUnits',
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _SummaryCard(
                  icon: Icons.water_drop_outlined,
                  label: 'Groups available',
                  value: '$availableGroups / 8',
                ),
              ),
            ],
          ),
          const SizedBox(height: 28),
          Text(
            'Blood stock overview',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          Card(
            child: Column(
              children: Stock.stockValues.entries.map((entry) {
                return ListTile(
                  leading: const Icon(Icons.bloodtype_outlined),
                  title: Text(entry.key),
                  subtitle: Text('${entry.value} units'),
                  trailing: Text(
                    statusFor(entry.value),
                    style: TextStyle(
                      color: statusColor(entry.value),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 28),
          Text(
            'Quick actions',
            style: Theme.of(context).textTheme.titleLarge,
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 52,
            child: ElevatedButton.icon(
              onPressed: () async {
                await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Stock()),
                );
                if (context.mounted) setState(() {});
              },
              icon: const Icon(Icons.edit_note),
              label: const Text('Manage Blood Stock'),
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 52,
            child: OutlinedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const BankProfile(),
                  ),
                );
              },
              icon: const Icon(Icons.business_outlined),
              label: const Text('Blood Bank Profile'),
            ),
          ),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            const SizedBox(height: 12),
            Text(
              value,
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 4),
            Text(label),
          ],
        ),
      ),
    );
  }
}